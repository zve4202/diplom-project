import React from 'react'

const ColumnGroupContext = React.createContext(null)
ColumnGroupContext.displayName = 'ColumnGroupContext'
export default ColumnGroupContext
