export const DragModes = Object.freeze({
  Resize: 'resize',
  Select: 'select'
})
export const GestureTargets = Object.freeze({
  Header: -2,
  BelowItems: -1
})
